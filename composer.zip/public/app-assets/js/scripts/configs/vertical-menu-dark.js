// Menu Icon Color Config
var menuIconColorsObj = {
  iconStrokeColor    : "#8baff3ad",
  iconSolidColor     : "#8baff3ad",
  iconFillColor      : "#d4ebf9",
  iconStrokeColorAlt : "#5A8DEE"
};


// Active Menu Icon Color Config
var menuActiveIconColorsObj = {
  iconStrokeColor    : "#8baff3ad",
  iconSolidColor     : "#8baff3ad",
  iconFillColor      : "#d4ebf9",
  iconStrokeColorAlt : "#5A8DEE"
};
